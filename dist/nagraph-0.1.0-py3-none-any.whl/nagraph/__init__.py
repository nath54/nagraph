# nagraph/__init__.py
from .graph import Graph, GraphNode